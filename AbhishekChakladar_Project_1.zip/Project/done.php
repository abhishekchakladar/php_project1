<div class="placeorder content-wrapper">
    <h2>Thanks for Shopping with US. Browse More products <a href='index.php'>here</a></h2>
</div>